package com.pwc.model;

public class IdUser {
	private String id;
	
	public IdUser() {
	}
	
	

	public IdUser(String id) {
		super();
		this.id = id;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	

}
