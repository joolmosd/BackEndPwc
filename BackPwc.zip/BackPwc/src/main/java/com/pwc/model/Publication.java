package com.pwc.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Publications")
public class Publication {
	
	String description;
	String url;
	
	public Publication() {}

	public Publication(String description, String url) {
		super();
		this.description = description;
		this.url = url;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
