package com.pwc.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Users")
public class User {
	
	@Id
	private String id="";
	private String email;
	private String names;
	private String lastNames;
	private String password;
	private String user;	
	private String rol;
	private String country;
	private String jobTitle;
	private boolean active;
	
	public User() {
		
	}

	public User(String names, String lastNames, String password, String email,  boolean active,
			String country, String jobTitle) {
		this.names = names;
		this.lastNames = lastNames;
		this.email = email;
		this.password = password;
		this.rol = "ADMIN";
		this.active = active;
		this.country = country;
		this.jobTitle = jobTitle;
		this.user = this.email;
	}

	
	public String getNames() {
		return names;
	}

	public void setNames(String names) {
		this.names = names;
	}

	public String getLastNames() {
		return lastNames;
	}

	public void setLastNames(String lastNames) {
		this.lastNames = lastNames;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
	

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	

	public String getIdentification() {
		return id;
	}

	public void setIdentification(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "User [names=" + names + ", lastNames=" + lastNames + ",  password=" + password + ", email=" + email + ", rol=" + rol + ", country="
				+ country + ", active=" + active + ", jobTitle=" + jobTitle + "]";
	}

}
