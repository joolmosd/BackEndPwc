package com.pwc.model;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoder {
	
	String password;
	
	
	public PasswordEncoder(String password) {
		this.password = password;
	}


	public String encoder() {
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	String hashedPassword = passwordEncoder.encode(this.password);
	return hashedPassword;
	}

}
