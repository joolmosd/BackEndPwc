package com.pwc.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.pwc.model.Mail;
import io.swagger.annotations.Api;
 
@CrossOrigin(origins = "http://localhost:4200")
@Api(tags = { "Class: MailController" }) // tag defined in SwaggerConfig.java
@RestController // Defines that this class is a spring bean
public class MailController {
 
	@Autowired
    JavaMailSender javaMailSend;
	
	/* JSON email...
	{
	    "mailTo": "wsoto@poligran.edu.co",
	    "mailSubject": "hola mundo",
	    "mailContent": "bienvenidos",
	    "attachments" : ["/Users/wilsonsoto/Downloads/TransaccionPNCBANK.pdf"]
	}
	*/
	
	@RequestMapping(value = "/api/v1/email", method=RequestMethod.GET)
	public String sendEmail(@RequestBody Mail mail){
		
		SimpleMailMessage msg = new SimpleMailMessage();
		
        msg.setTo(mail.getMailTo());
        msg.setSubject(mail.getMailSubject());
        msg.setText(mail.getMailContent());
        
		javaMailSend.send(msg);
		return "Email sent successfully";
	}
	
}