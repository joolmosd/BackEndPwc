package com.pwc.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pwc.model.Publication;
import com.pwc.repository.PublicationRepository;

import io.swagger.annotations.Api;

@CrossOrigin(origins = "https://frontpwc.herokuapp.com/")
@Api(tags = { "Class: PublicationController" })
@RestController
@RequestMapping("/api/v1/")
public class PublicationController {
	
	 @Autowired
	 PublicationRepository publicationRepository;
	 
	 @PostMapping("/postPublication")
	 public Publication postPublication(@RequestBody Publication publication){
		 
		 return publicationRepository.save(publication);
		 
	 }
	 
	 @PostMapping("/postListPublications")
	 public List<Publication> postListPublications(@RequestBody List<Publication> publications){
		 return publicationRepository.saveAll(publications);
	 }
	 
	 @GetMapping("/getPublication/{id}")
	 public ResponseEntity<Publication> getPublication(@PathVariable String id) {
	
		 if (publicationRepository.existsById(id)) {
			 Publication publication = publicationRepository.findById(id).get();
				return ResponseEntity.status(HttpStatus.OK).body(publication);
			} else {
				return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);

			}
	 }
	 
	 @GetMapping("/getAllPublications")
	 public List<Publication> getAllPublications(){
		 return publicationRepository.findAll();
	 }
	 
	 @PutMapping("/putPublication/{id}")
	 public Publication putPublication(@RequestBody Publication publication, @PathVariable String id) {
		 
		 Publication update_publication = publicationRepository.findById(id).get();
		 
		 update_publication.setDescription(publication.getDescription());
		 update_publication.setUrl(publication.getUrl());
		 
		 publicationRepository.save(update_publication);
		 return update_publication;
		 
	 }
	 
	 @DeleteMapping("/deletePublication/{id}")
	 public String deletePublication(@PathVariable String id) {
		 publicationRepository.deleteById(id);
		 return "Publication Deleted";
		 
	 }
	 
	 @DeleteMapping("/deleteAllPublications")
	 public String deleteAllPublications() {
		 publicationRepository.deleteAll();
		 return "Publications Deleted";
	 }
	 

}
