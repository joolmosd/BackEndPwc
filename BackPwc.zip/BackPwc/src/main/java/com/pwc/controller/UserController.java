package com.pwc.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pwc.model.IdUser;
import com.pwc.model.PasswordEncoder;
import com.pwc.model.User;
import com.pwc.repository.UserRepository;
import io.swagger.annotations.Api;

@CrossOrigin(origins = "https://frontpwc.herokuapp.com/")
@Api(tags = { "Class: UserController" }) // tag defined in SwaggerConfig.java
@RestController // Defines that this class is a spring bean
@RequestMapping("/api/v1/")
public class UserController {

	@Autowired
	UserRepository userRepository;

	@PostMapping("/postUser")
	public User postUser(@RequestBody User user) {
		
		PasswordEncoder passwordEncoder = new PasswordEncoder(user.getPassword());
		//System.out.println("Contraseña sin Encryptar : " + user.getPassword());
		user.setPassword(passwordEncoder.encoder());
		//System.out.println("Contraseña Encryptada : " + user.getPassword() );
		String email[] = user.getEmail().split("@");
		user.setIdentification(email[0]);
		return userRepository.save(user);
	}

	@PostMapping("/postListUsers")
	public List<User> postListUsuarios(@RequestBody List<User> users) {
		return userRepository.saveAll(users);
	}

	@GetMapping("/getUser/{id}")
	public ResponseEntity<User> getUsuario(@PathVariable String id) {

		User user = userRepository.findById(id).get();
		if (user!=null) {
			return ResponseEntity.status(HttpStatus.OK).body(user);
		} else {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);

		}
	}
	
	@GetMapping("/getAllUsers")
	public List<User> getAllUsuario() {
		return userRepository.findAll();
	}
	
	@GetMapping("/login/{userName}/{password}")
	public  IdUser login(@PathVariable String userName, @PathVariable String password) {
		
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();  
		//encoderPass.setPassword(password);
		User userLogin = userRepository.login(userName);
		boolean bycr = encoder.matches(password, userLogin.getPassword());
		IdUser idUser = userRepository.findName(userName);
		//System.out.println(bycr);
		//String passwordCompare = encoderPass.encoder();
		//User userLogin = userRepository.login(userName, passwordCompare);
		//User userLogin = userRepository.login(userName, password);
		
		if(userLogin != null  ) {
			
			if(bycr == true) {
				System.out.println(idUser.getId());
				return idUser;
			}
			
		}
			return null;	
	
	}

	
	@GetMapping("/getUserName/{userName}")
	public   User userName(@PathVariable String userName) {
		return userRepository.userName(userName); 
	}

	

	@PutMapping("/putUser/{id}")
	public User putUsuario(@RequestBody User user, @PathVariable String id) {

		User update_user = userRepository.findById(id).get();
		update_user.setNames(user.getNames());
		update_user.setLastNames(user.getLastNames());
		update_user.setEmail(user.getEmail());
		update_user.setCountry(user.getCountry());
		update_user.setJobTitle(user.getJobTitle());
		
		System.out.println("Usuario ya Actualizado :" + update_user.getEmail());
		

		userRepository.save(update_user);
		return update_user;
	}

	@DeleteMapping("/deleteUser/{id}")
	public String deleteUsuarioById(@PathVariable String id) {
		userRepository.deleteById(id);
		return "User Deleted!!";
	}

	@DeleteMapping("/deleteAllUsers")
	public String deleteAllUsers() {
		userRepository.deleteAll();
		return "Users Deleted!!";
	}
}
