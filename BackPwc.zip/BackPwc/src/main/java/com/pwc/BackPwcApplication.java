package com.pwc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackPwcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackPwcApplication.class, args);
	}

}
