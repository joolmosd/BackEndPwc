package com.pwc.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.pwc.model.IdUser;
import com.pwc.model.User;

public interface UserRepository extends MongoRepository<User, String> {
	
	User findByUser(String userName);
	
	@Query("{'email': ?0 }")
	User login(String userName);
	
	@Query(value = "{'email': ?0}", fields = "{'_id':1}")
	IdUser findName(String id);
	
	
	@Query("{ 'email' : ?0 }")
	User userName(String userName);

	
	@Query("{ '_id' : ObjectId(?0) }")
	User findId(String userName);
	
}
