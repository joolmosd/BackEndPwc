package com.pwc.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.pwc.model.Publication;

public interface PublicationRepository extends MongoRepository<Publication, String> {

}
